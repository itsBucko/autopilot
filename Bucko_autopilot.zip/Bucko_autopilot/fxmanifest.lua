fx_version 'cerulean'
game 'gta5'

author 'itsBucko'
description 'Bucko Autopilot - Walk or Drive to Waypoint'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}