-- config.lua

BuckoConfig = {
    EnableWalkingAutopilot = true,
    EnableDrivingAutopilot = true
}
